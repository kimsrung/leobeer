TEXT_GAMEOVER  = "GAME OVER";
TEXT_PLAY      = "ធម្មតា";
TEXT_PLAYCHALLENGE = "ពិបាក";

TEXT_SCORE	= "ពិន្ទុ: ";
TEXT_HISCORE = "ពិន្ទុខ្ពស់បំផុត: ";
TEXT_NEWHISCORE = "បំបែកឯកកត្តកម្ម!!";

TEXT_GRAVITY = "GRAVITY: ";
TEXT_HIGRAVITY = "TOP GRAVITY: ";
TEXT_NEWHIGRAVITY = "NEW HIGHEST GRAVITY!!";
TEXT_TIME = "TIME";
TEXT_CREDITS_DEVELOPED = "DEVELOPED BY";
TEXT_LINK = "http://d-arrow.com/";

TEXT_SUPPORT_STRINGS = 4;
TEXT_SUPPORT = [];
TEXT_SUPPORT[0] = "ល្អ!";
TEXT_SUPPORT[1] = "ឡូយ!";
TEXT_SUPPORT[2] = "មិនធម្មតា!!";
TEXT_SUPPORT[3] = "អស្ចារ្យ!";

TEXT_SHARE_IMAGE = "200x200.jpg";
TEXT_SHARE_TITLE = "Congratulations!";
TEXT_SHARE_MSG1 = "You collected <strong>";
TEXT_SHARE_MSG2 = " points</strong>!<br><br>Share your score with your friends!";
TEXT_SHARE_SHARE1 = "My score is ";
TEXT_SHARE_SHARE2 = " points! Can you do better?";
